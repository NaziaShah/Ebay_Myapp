import ebaysdk
from ebaysdk import finding

api = finding(siteid='EBAY-US', appid='')

api.execute('findItemsAdvanced', {
    'keywords': 'upc',
    
    'itemFilter': [
        {'name': 'Condition', 'value': 'Used'},
        {'name': 'MinPrice', 'value': '200', 'paramName': 'Currency', 'paramValue': 'INR'},
        {'name': 'MaxPrice', 'value': '400', 'paramName': 'Currency', 'paramValue': 'INR'}
    ],
    'paginationInput': {
        'entriesPerPage': '1',
        'pageNumber': '1' 	 
    },

})

dictstr = api.response_dict()

for item in dictstr['searchResult']['item']:
    print "ItemID: %s" % item['itemId'].value
    print "Title: %s" % item['title'].value
    print "CategoryID: %s" % item['primaryCategory']['categoryId'].value
    print "Price: %s" % item['price'].value